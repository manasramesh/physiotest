from flask import Flask, render_template, request, redirect, url_for, session
import json
import random
import os

app = Flask(__name__, static_folder='static')
app.secret_key = os.urandom(24)

def load_questions(filepath):
    with open(filepath, 'r') as file:
        questions = json.load(file)
    return questions

def load_users(filepath='users.json'):
    if os.path.exists(filepath):
        with open(filepath, 'r') as file:
            return json.load(file)
    return {}

def save_users(users, filepath='users.json'):
    with open(filepath, 'w') as file:
        json.dump(users, file, indent=4)

def load_history(filepath='history.json'):
    if os.path.exists(filepath):
        with open(filepath, 'r') as file:
            return json.load(file)
    return {}

def save_history(history, filepath='history.json'):
    with open(filepath, 'w') as file:
        json.dump(history, file, indent=4)

@app.route('/')
def home():
    if 'username' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        users = load_users()
        if username in users:
            return "Username already exists!"
        users[username] = {'password': password, 'history': []}
        save_users(users)
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        users = load_users()
        if username in users and users[username]['password'] == password:
            session['username'] = username
            return redirect(url_for('dashboard'))
        return "Invalid credentials!"
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('home'))

@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))
    username = session['username']
    users = load_users()
    history = users[username]['history']
    return render_template('dashboard.html', history=history)

@app.route('/start_test', methods=['POST'])
def start_test():
    if 'username' not in session:
        return redirect(url_for('login'))
    name = session['username']
    
    questions = load_questions('questions.json')
    
    # Get previously used questions from session
    previous_questions = session.get('previous_questions', [])
    
    # Filter out previously used questions
    available_questions = [q for q in questions if q['question'] not in previous_questions]
    
    # If not enough questions, reset the previous questions list
    if len(available_questions) < 20:
        previous_questions = []
        available_questions = questions
    
    # Ensure there are enough questions to select from
    if len(available_questions) < 20:
        return "Not enough questions available to start the test."
    
    selected_questions = random.sample(available_questions, 20)
    
    # Update the session with the current set of questions
    session['selected_questions'] = selected_questions
    session['previous_questions'] = [q['question'] for q in selected_questions]
    
    return render_template('test.html', questions=selected_questions, enumerate=enumerate, name=name)

@app.route('/submit_test', methods=['POST'])
def submit_test():
    if 'username' not in session:
        return redirect(url_for('login'))
    name = session['username']
    selected_questions = session.get('selected_questions', [])
    score = 0
    incorrect_questions = []
    for i, question in enumerate(selected_questions):
        selected_option = request.form.get(f'question_{i}')
        if selected_option and question['options'][int(selected_option)-1] == question['answer']:
            score += 1
        else:
            incorrect_questions.append({
                'question': question['question'],
                'selected_option': question['options'][int(selected_option)-1] if selected_option else None,
                'correct_answer': question['answer']
            })
    total_questions = len(selected_questions)
    pass_mark = total_questions * 0.75
    result = "Pass" if score >= pass_mark else "Fail"
    
    # Save history
    users = load_users()
    users[name]['history'].append({
        'score': score,
        'total': total_questions,
        'result': result,
        'incorrect_questions': incorrect_questions
    })
    save_users(users)
    
    return render_template('result.html', score=score, total=total_questions, incorrect_questions=incorrect_questions, result=result, name=name)

@app.route('/new_exam')
def new_exam():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('home.html')

if __name__ == "__main__":
    app.run(debug=True)
